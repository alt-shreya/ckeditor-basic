export default {
	server: {
		open: 'index.html'
	}
};
